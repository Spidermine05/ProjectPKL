/* Editor langsung di halaman (hanya dimuat saat login sebagai admin) */
(() => {
  'use strict';

  const csrf = document.querySelector('meta[name="csrf"]').content;
  const $ = (s, r = document) => r.querySelector(s);
  const btnToggle = $('#ed-toggle');
  const btnSave = $('#ed-save');
  const btnDiscard = $('#ed-discard');
  const bar = $('#ed-bar');
  const saveLabel = $('.ed-label', btnSave);
  document.documentElement.classList.add('ed-admin');
  const dirty = new Map();          // kunci -> nilai baru
  let saving = false;
  const orig = new WeakMap();       // elemen -> nilai awal
  let on = false;

  /* ---------- Util ---------- */
  const editables = () => [...document.querySelectorAll('[data-edit]')];

  const valueOf = (el) => {
    let v = el.innerText.replace(/\r/g, '').replace(/ /g, ' ');
    v = el.hasAttribute('data-multiline') ? v.replace(/\n{3,}/g, '\n\n') : v.replace(/\s*\n+\s*/g, ' ');
    return v.trim();
  };

  async function post(url, body, isJson = false) {
    const headers = { 'X-CSRF-Token': csrf };
    if (isJson) headers['Content-Type'] = 'application/json';
    const res = await fetch(url, {
      method: 'POST', headers, credentials: 'same-origin',
      body: isJson ? JSON.stringify(body) : body,
    });
    let data;
    try { data = await res.json(); } catch (e) { throw new Error('Respons server tidak valid.'); }
    if (!res.ok || !data.ok) throw new Error(data.error || 'Terjadi kesalahan.');
    return data;
  }

  let toastTimer;
  function toast(msg, type) {
    let t = $('#ed-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'ed-toast';
      t.setAttribute('role', 'status');
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = 'ed-toast show ' + (type === 'err' ? 'err' : 'ok');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
  }

  function refresh() {
    // aria-disabled (bukan disabled) supaya tombol tetap menerima sentuhan dan tooltip-nya bisa tampil
    btnSave.setAttribute('aria-disabled', String(dirty.size === 0 || saving));
    btnDiscard.setAttribute('aria-disabled', String(dirty.size === 0));
    saveLabel.textContent = dirty.size ? `Simpan (${dirty.size})` : 'Simpan';
    btnSave.dataset.count = dirty.size ? String(dirty.size) : '';
    if (dirty.size) revealBar();
  }

  /* ---------- Mode edit ---------- */
  function setEdit(state) {
    on = state;
    document.body.classList.toggle('edit-on', on);
    btnToggle.setAttribute('aria-pressed', String(on));
    $('.ed-label', btnToggle).textContent = on ? 'Mode Edit: Aktif' : 'Mode Edit: Mati';
    btnToggle.title = on ? 'Mode Edit aktif. Ketuk untuk mematikan' : 'Mode Edit mati. Ketuk untuk menyalakan';
    editables().forEach((el) => {
      if (on) {
        el.setAttribute('contenteditable', 'true');
        el.setAttribute('spellcheck', 'true');
        el.setAttribute('title', 'Klik untuk mengedit');
      } else {
        el.removeAttribute('contenteditable');
        el.removeAttribute('title');
      }
    });
    // Nilai awal diambil saat mode edit aktif (agar sesuai tampilan tanpa transformasi huruf)
    if (on) editables().forEach((el) => { if (!orig.has(el)) orig.set(el, valueOf(el)); });
    try { localStorage.setItem('ed-on', on ? '1' : '0'); } catch (e) { /* abaikan */ }
  }
  btnToggle.addEventListener('click', () => setEdit(!on));

  /* ---------- Pelacakan perubahan teks ---------- */
  document.addEventListener('input', (e) => {
    const el = e.target.closest && e.target.closest('[data-edit]');
    if (!el || !on) return;
    const v = valueOf(el);
    if (v === orig.get(el)) dirty.delete(el.dataset.edit); else dirty.set(el.dataset.edit, v);
    refresh();
  });

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && on) { e.preventDefault(); save(); return; }
    const el = e.target.closest && e.target.closest('[data-edit]');
    if (el && on && e.key === 'Enter' && !el.hasAttribute('data-multiline')) { e.preventDefault(); el.blur(); }
  });

  // Tempel sebagai teks biasa agar format dari web lain tidak ikut
  document.addEventListener('paste', (e) => {
    const el = e.target.closest && e.target.closest('[data-edit]');
    if (!el || !on) return;
    e.preventDefault();
    const text = (e.clipboardData || window.clipboardData).getData('text/plain');
    document.execCommand('insertText', false, text);
  });

  // Tautan/tombol yang teksnya bisa diedit tidak boleh berpindah halaman saat diklik
  document.addEventListener('click', (e) => {
    if (!on) return;
    const a = e.target.closest('a');
    if (a && (a.hasAttribute('data-edit') || a.querySelector('[data-edit]'))) e.preventDefault();
  }, true);

  /* ---------- Simpan / batalkan ---------- */
  async function save() {
    if (!dirty.size || saving) return;
    saving = true;
    refresh();
    saveLabel.textContent = 'Menyimpan…';
    const batch = new Map(dirty);       // salinan: ketikan baru selama proses simpan tidak ikut terhapus
    try {
      await post('api/save.php', { changes: Object.fromEntries(batch) }, true);
      batch.forEach((v, k) => {
        const el = document.querySelector(`[data-edit="${k}"]`);
        if (el) orig.set(el, v);
        if (dirty.get(k) === v) dirty.delete(k);
      });
      toast('Perubahan tersimpan ✓');
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      saving = false;
      refresh();
    }
  }
  btnSave.addEventListener('click', save);
  btnDiscard.addEventListener('click', () => {
    if (dirty.size && confirm('Buang semua perubahan yang belum disimpan?')) {
      dirty.clear();
      location.reload();
    }
  });
  $('#ed-logout').addEventListener('submit', (e) => {
    if (dirty.size && !confirm('Ada perubahan yang belum disimpan. Tetap keluar?')) e.preventDefault();
    else dirty.clear();
  });
  addEventListener('beforeunload', (e) => {
    if (dirty.size) { e.preventDefault(); e.returnValue = ''; }
  });

  /* ---------- Ganti foto ---------- */
  function applyImage(key, url) {
    document.querySelectorAll(`[data-image="${key}"]`).forEach((img) => { img.src = url; });
    document.querySelectorAll(`[data-bg="${key}"]`).forEach((el) => {
      el.classList.add('has-img');
      el.style.backgroundImage = `linear-gradient(rgba(20,13,9,.55),rgba(20,13,9,.8)),url("${url}")`;
    });
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-upload]');
    if (!b) return;
    e.preventDefault();
    e.stopPropagation();
    const key = b.dataset.upload;
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/jpeg,image/png,image/webp';
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) return;
      if (file.size > 5 * 1024 * 1024) { toast('Ukuran foto maksimal 5 MB.', 'err'); return; }
      const fd = new FormData();
      fd.append('key', key);
      fd.append('file', file);
      b.disabled = true;
      toast('Mengunggah foto…');
      try {
        const d = await post('api/upload.php', fd);
        applyImage(key, d.url);
        toast('Foto berhasil diganti ✓');
      } catch (err) {
        toast(err.message, 'err');
      } finally {
        b.disabled = false;
      }
    });
    input.click();
  });

  /* ---------- Menu: tambah / ubah / hapus ---------- */
  const dlg = $('#menu-dialog');
  const form = $('#menu-form');
  const field = (n) => form.querySelector(`[name="${n}"]`);
  const preview = $('#menu-photo-preview');
  const removeWrap = $('#remove-photo-wrap');
  const DEFAULT_PREVIEW = 'assets/img/ph-main.svg';

  function openMenu(card) {
    form.reset();
    field('id').value = card ? card.dataset.id : '';
    field('name').value = card ? card.dataset.name : '';
    field('category').value = card ? card.dataset.category : '';
    field('price').value = card && Number(card.dataset.price) > 0 ? card.dataset.price : '';
    field('description').value = card ? card.dataset.desc : '';
    const hasImg = !!(card && card.dataset.image);
    preview.src = hasImg ? card.dataset.image : DEFAULT_PREVIEW;
    removeWrap.hidden = !hasImg;
    $('#menu-dialog-title').textContent = card ? 'Ubah Menu' : 'Tambah Menu';
    dlg.showModal();
  }

  function replaceMenu(html) {
    $('#menu-wrap').innerHTML = html;
    if (window.initMenu) window.initMenu();
  }

  document.addEventListener('click', async (e) => {
    if (e.target.closest('[data-menu-add]')) { openMenu(null); return; }
    const edit = e.target.closest('[data-menu-edit]');
    if (edit) { openMenu(edit.closest('.dish')); return; }
    const del = e.target.closest('[data-menu-del]');
    if (del) {
      const card = del.closest('.dish');
      if (!confirm(`Hapus menu "${card.dataset.name}"?`)) return;
      const fd = new FormData();
      fd.append('action', 'delete');
      fd.append('id', card.dataset.id);
      try {
        const d = await post('api/menu.php', fd);
        replaceMenu(d.html);
        toast('Menu dihapus');
      } catch (err) { toast(err.message, 'err'); }
    }
  });

  field('photo').addEventListener('change', () => {
    const f = field('photo').files[0];
    if (f) { preview.src = URL.createObjectURL(f); removeWrap.hidden = true; }
  });
  $('#menu-cancel').addEventListener('click', () => dlg.close());
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    const fd = new FormData(form);
    fd.set('action', 'save');
    btn.disabled = true;
    try {
      const d = await post('api/menu.php', fd);
      replaceMenu(d.html);
      dlg.close();
      toast('Menu tersimpan ✓');
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      btn.disabled = false;
    }
  });

  /* ---------- Toolbar: otomatis menyingkir di layar kecil ----------
     Saat menggulir ke bawah toolbar turun keluar layar supaya tidak menutupi konten,
     lalu muncul lagi begitu menggulir ke atas, saat ada perubahan, atau saat panel tema dibuka. */
  const compact = matchMedia('(max-width: 760px)');
  const panel = $('#ed-theme-panel');
  const panelOpen = () => panel.classList.contains('is-open');

  function setBarHidden(hidden) {
    bar.classList.toggle('is-hidden', hidden);
    document.body.classList.toggle('ed-bar-hidden', hidden);
  }
  function revealBar() { setBarHidden(false); }

  let lastY = scrollY;
  addEventListener('scroll', () => {
    if (!compact.matches) return;
    const y = scrollY, delta = y - lastY;
    if (Math.abs(delta) < 8) return;
    const nearBottom = innerHeight + y >= document.documentElement.scrollHeight - 80;
    const keepOpen = panelOpen() || dirty.size > 0;   // fokus tombol yang tertinggal setelah disentuh sengaja tidak dihitung
    setBarHidden(delta > 0 && y > 120 && !nearBottom && !keepOpen);
    lastY = y;
  }, { passive: true });
  compact.addEventListener('change', revealBar);
  bar.addEventListener('focusin', revealBar);
  document.addEventListener('focusin', (e) => { if (e.target.closest && e.target.closest('[data-edit]')) revealBar(); });

  /* ---------- Panel tema ---------- */
  const T = window.DNTheme;
  const themeBtn = $('#ed-theme-btn');
  const presetBox = $('#ed-presets');
  const warn = $('#ed-theme-warn');
  const controls = {
    bg: $('#ed-theme-bg'), text: $('#ed-theme-text'),
    accent: $('#ed-theme-accent'), accent2: $('#ed-theme-accent2'),
  };
  const hexLabels = { bg: $('#hex-bg'), text: $('#hex-text'), accent: $('#hex-accent'), accent2: $('#hex-accent2') };

  // Kartu tema siap pakai dibuat dari data PRESETS (satu sumber kebenaran)
  Object.entries(T.PRESETS).forEach(([id, p]) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'ed-swatch';
    b.dataset.preset = id;
    b.setAttribute('role', 'radio');
    b.setAttribute('aria-checked', 'false');
    b.style.cssText = `--b:${p.bg};--t:${p.text};--a:${p.accent};--a2:${p.accent2}`;
    b.innerHTML = '<span class="sw-card"><span class="sw-pill"></span><span class="sw-dot"></span>' +
                  '<span class="sw-check" aria-hidden="true">✓</span></span><span class="sw-name"></span>';
    $('.sw-name', b).textContent = p.name;
    presetBox.appendChild(b);
  });

  function syncPanel(th) {
    T.KEYS.forEach((k) => {
      if (controls[k].value !== th[k]) controls[k].value = th[k];
      hexLabels[k].textContent = th[k];
    });
    const id = T.presetOf(th);
    presetBox.querySelectorAll('.ed-swatch').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.preset === id)));
    warn.hidden = T.contrast(th.text, th.bg) >= 4.5;
  }
  document.addEventListener('dn-theme', (e) => syncPanel(e.detail));
  syncPanel(T.current());

  // Tema disimpan ke server otomatis (ditunda sebentar agar tidak mengirim saat warna sedang digeser)
  let themeTimer = null;
  const themeBody = () => JSON.stringify({ changes: { 'theme.data': JSON.stringify(T.current()) } });
  function queueThemeSave() {
    clearTimeout(themeTimer);
    themeTimer = setTimeout(async () => {
      themeTimer = null;
      try {
        await post('api/save.php', JSON.parse(themeBody()), true);
        toast('Tema tersimpan untuk semua pengunjung ✓');
      } catch (err) { toast(err.message, 'err'); }
    }, 700);
  }
  // Jika halaman ditutup / pindah tab sebelum jeda 0,7 detik habis, kirim sekarang juga (keepalive tetap jalan setelah halaman tutup)
  function flushThemeSave() {
    if (themeTimer === null) return;
    clearTimeout(themeTimer);
    themeTimer = null;
    try {
      fetch('api/save.php', {
        method: 'POST', keepalive: true, credentials: 'same-origin',
        headers: { 'X-CSRF-Token': csrf, 'Content-Type': 'application/json' }, body: themeBody(),
      });
    } catch (err) { /* abaikan */ }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushThemeSave(); });
  addEventListener('pagehide', flushThemeSave);

  // Peringatan kontras punya tombol "Perbaiki": pilih warna teks (gelap/terang) yang paling terbaca di atas latar
  $('#ed-theme-fix').addEventListener('click', () => {
    const th = T.current();
    const dark = '#201712', light = '#f6f0e8';
    T.apply({ ...th, text: T.contrast(dark, th.bg) >= T.contrast(light, th.bg) ? dark : light }, { animate: true });
    queueThemeSave();
  });

  presetBox.addEventListener('click', (e) => {
    const b = e.target.closest('.ed-swatch');
    if (!b) return;
    T.apply(T.PRESETS[b.dataset.preset], { animate: true });
    queueThemeSave();
  });
  T.KEYS.forEach((k) => controls[k].addEventListener('input', () => {
    T.apply({ ...T.current(), [k]: controls[k].value });
    queueThemeSave();
  }));
  $('#ed-theme-reset').addEventListener('click', () => {
    T.apply(T.PRESETS.original, { animate: true });
    queueThemeSave();
  });

  function setPanel(open) {
    panel.classList.toggle('is-open', open);
    themeBtn.setAttribute('aria-expanded', String(open));
    if (open) revealBar();
  }
  themeBtn.addEventListener('click', () => setPanel(!panelOpen()));
  $('#ed-theme-close').addEventListener('click', () => { setPanel(false); themeBtn.focus(); });
  // 'click' (bukan pointerdown) agar menggulir halaman saat panel terbuka tidak menutupnya
  document.addEventListener('click', (e) => {
    if (panelOpen() && !e.target.closest('#ed-theme-panel, #ed-theme-btn')) setPanel(false);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panelOpen()) { setPanel(false); themeBtn.focus(); }
  });

  /* ---------- Tooltip di layar sentuh ----------
     Layar sentuh tidak punya hover, jadi atribut title tidak pernah tampil di HP.
     Tekan-tahan (±0,4 detik) sebuah tombol ikon untuk melihat namanya; melepas jari TIDAK menjalankan tombol itu.
     Di laptop tooltip yang sama muncul saat kursor diarahkan ke tombol atau saat tombol difokus dengan keyboard. */
  const TIP_TARGET = '.ed-bar .ed-btn, .ed-img-btn, .chip, .ed-x';
  const tip = document.createElement('div');
  tip.className = 'ed-tip';
  tip.setAttribute('role', 'tooltip');
  tip.setAttribute('aria-hidden', 'true');
  document.body.appendChild(tip);

  let tipTimer, tipHide, hoverTimer, tipFrom = '', pressX = 0, pressY = 0, swallowClickUntil = 0;

  // Atribut title dipindah ke data-tip agar tooltip bawaan browser tidak muncul dobel di samping tooltip kita
  function takeTitle(el) {
    const t = el.getAttribute('title');
    if (t) { el.dataset.tip = t; el.removeAttribute('title'); }
  }
  function tipText(el, touch) {
    takeTitle(el);
    const raw = el.dataset.tip || el.getAttribute('aria-label') || ($('.ed-label', el) || {}).textContent || '';
    return touch ? raw.replace(/\s*\(Ctrl\+S\)/, '').trim() : raw.trim();   // pintasan keyboard tidak relevan di HP
  }
  function showTip(el, touch = true, from = 'touch') {
    const text = tipText(el, touch);
    if (!text) return;
    tip.textContent = text;
    tipFrom = from;                                      // 'touch' | 'mouse' | 'focus': siapa yang memintanya
    tip.classList.remove('below');
    const r = el.getBoundingClientRect(), tw = tip.offsetWidth, th = tip.offsetHeight, vw = document.documentElement.clientWidth;
    const left = Math.max(8, Math.min(vw - tw - 8, r.left + r.width / 2 - tw / 2));
    let top = r.top - th - 12;
    if (top < 8) { top = r.bottom + 12; tip.classList.add('below'); }
    tip.style.left = left + 'px';
    tip.style.top = top + 'px';
    tip.style.setProperty('--ax', Math.max(14, Math.min(tw - 14, r.left + r.width / 2 - left)) + 'px');
    tip.classList.add('show');
    if (touch) swallowClickUntil = Date.now() + 700;    // klik susulan setelah tekan-tahan diabaikan
  }
  function hideTip() { clearTimeout(tipTimer); clearTimeout(tipHide); clearTimeout(hoverTimer); tip.classList.remove('show'); }

  document.addEventListener('pointerdown', (e) => {
    hideTip();
    if (e.pointerType === 'mouse') return;
    const el = e.target.closest && e.target.closest(TIP_TARGET);
    if (!el) return;
    pressX = e.clientX; pressY = e.clientY;
    tipTimer = setTimeout(() => showTip(el), 400);
  });
  document.addEventListener('pointermove', (e) => {
    if (tipTimer && Math.hypot(e.clientX - pressX, e.clientY - pressY) > 10) clearTimeout(tipTimer);
  });
  const release = () => {
    clearTimeout(tipTimer);
    if (tip.classList.contains('show')) { clearTimeout(tipHide); tipHide = setTimeout(hideTip, 1600); }
  };
  // Mouse: tooltip muncul sebentar setelah kursor berhenti di tombol, hilang saat kursor pergi atau tombol diklik
  document.addEventListener('pointerover', (e) => {
    if (e.pointerType !== 'mouse') return;
    const el = e.target.closest && e.target.closest(TIP_TARGET);
    if (!el) return;
    takeTitle(el);                                       // cegah tooltip bawaan sebelum sempat muncul
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => showTip(el, false, 'mouse'), 350);
  });
  document.addEventListener('pointerout', (e) => {
    if (e.pointerType !== 'mouse') return;
    const el = e.target.closest && e.target.closest(TIP_TARGET);
    if (el && !el.contains(e.relatedTarget)) { clearTimeout(hoverTimer); hideTip(); }
  });
  // Keyboard: tooltip tampil saat tombol difokus dengan Tab
  document.addEventListener('focusin', (e) => {
    const el = e.target.closest && e.target.closest(TIP_TARGET);
    if (el && el.matches(':focus-visible')) showTip(el, false, 'focus');
  });
  // Hanya tooltip hasil fokus keyboard yang ditutup saat fokus pergi (browser juga memindahkan fokus setelah sentuhan)
  document.addEventListener('focusout', () => { if (tipFrom === 'focus') hideTip(); });
  document.addEventListener('pointerup', release);
  document.addEventListener('pointercancel', release);
  addEventListener('scroll', hideTip, { passive: true });
  // Jangan jalankan aksi tombol bila yang terjadi adalah tekan-tahan untuk melihat tooltip
  document.addEventListener('click', (e) => {
    if (Date.now() < swallowClickUntil && e.target.closest && e.target.closest(TIP_TARGET)) {
      e.preventDefault(); e.stopImmediatePropagation();
    }
  }, true);
  // Cegah menu "salin / bagikan" bawaan browser saat tekan-tahan pada tombol toolbar
  document.addEventListener('contextmenu', (e) => {
    if (e.target.closest && e.target.closest(TIP_TARGET)) e.preventDefault();
  });

  /* ---------- Mulai ---------- */
  let startOn = true;
  try { startOn = localStorage.getItem('ed-on') !== '0'; } catch (e) { /* abaikan */ }
  setEdit(startOn);
  refresh();
})();
