<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

// Form kontak publik. Form-data: name, contact, message, website (honeypot)
try {
    api_guard(false);

    // Honeypot: bot biasanya mengisi kolom tersembunyi ini
    if (trim((string)($_POST['website'] ?? '')) !== '') {
        json_out(['ok' => true, 'message' => 'Terima kasih! Pesan Anda sudah kami terima.']);
    }

    // Batasi pengiriman beruntun dari sesi yang sama
    $last = (int)($_SESSION['last_msg'] ?? 0);
    if (time() - $last < 20) {
        json_out(['ok' => false, 'error' => 'Mohon tunggu sebentar sebelum mengirim pesan lagi.'], 429);
    }

    $name    = clean_text((string)($_POST['name'] ?? ''), 80);
    $contact = clean_text((string)($_POST['contact'] ?? ''), 120);
    $message = clean_text((string)($_POST['message'] ?? ''), 1500);

    if ($name === '' || $contact === '' || $message === '') {
        json_out(['ok' => false, 'error' => 'Nama, kontak, dan pesan wajib diisi.'], 422);
    }
    if (strlen($message) < 5) {
        json_out(['ok' => false, 'error' => 'Pesan terlalu singkat.'], 422);
    }

    db()->prepare('INSERT INTO messages (name, contact, message, created_at) VALUES (?, ?, ?, ?)')
        ->execute([$name, $contact, $message, date('Y-m-d H:i:s')]);
    $_SESSION['last_msg'] = time();

    json_out(['ok' => true, 'message' => 'Terima kasih! Pesan Anda sudah kami terima dan akan segera kami balas.']);
} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'Pesan gagal dikirim. Silakan coba lagi.'], 500);
}
