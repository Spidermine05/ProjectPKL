<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

// Mengganti foto situs (hero, tentang, galeri). Form-data: key, file
try {
    api_guard();

    $key = (string)($_POST['key'] ?? '');
    if (!in_array($key, image_keys(), true)) {
        json_out(['ok' => false, 'error' => 'Target foto tidak dikenal.'], 422);
    }
    if (!isset($_FILES['file'])) {
        json_out(['ok' => false, 'error' => 'Belum ada foto yang dipilih.'], 422);
    }

    $old = img($key);
    $url = save_upload($_FILES['file']);
    set_setting($key, $url);
    delete_upload($old);

    json_out(['ok' => true, 'url' => $url]);
} catch (RuntimeException $ex) {
    json_out(['ok' => false, 'error' => $ex->getMessage()], 422);
} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'Terjadi kesalahan: ' . $ex->getMessage()], 500);
}
