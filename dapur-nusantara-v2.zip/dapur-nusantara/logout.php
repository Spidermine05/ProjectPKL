<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';

// Keluar hanya lewat POST + token CSRF agar tidak bisa dipicu dari situs lain
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valid($_POST['csrf'] ?? null)) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
}
redirect('index.php');
