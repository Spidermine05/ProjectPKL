<?php
/**
 * Router untuk server bawaan PHP (khusus pengembangan lokal):
 *   php -S localhost:8000 router.php
 * Server bawaan tidak membaca .htaccess, jadi folder internal diblokir di sini.
 * Tidak dipakai di Apache/XAMPP/Laragon/hosting biasa.
 */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = rawurldecode($path);

if (preg_match('#^/(data|includes)(/|$)#', $path)) {
    http_response_code(403);
    echo 'Forbidden';
    return true;
}
if (preg_match('#^/uploads/.*\.(php|phtml|phar)$#i', $path)) {
    http_response_code(403);
    echo 'Forbidden';
    return true;
}
return false; // serahkan ke server bawaan
