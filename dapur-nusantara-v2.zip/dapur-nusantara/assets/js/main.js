/* Skrip publik: navigasi, animasi muncul, tab menu, dan form kontak */
(() => {
  'use strict';
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* Header berubah saat digulir */
  const header = $('.site-header');
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 40);
  onScroll();
  addEventListener('scroll', onScroll, { passive: true });

  /* Menu mobile */
  const toggle = $('.nav-toggle');
  const nav = $('#nav');
  const setNav = (open) => {
    nav.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
    document.body.classList.toggle('nav-open', open);
  };
  toggle.addEventListener('click', () => setNav(!nav.classList.contains('open')));
  $$('#nav a').forEach((a) => a.addEventListener('click', () => setNav(false)));
  addEventListener('keydown', (e) => { if (e.key === 'Escape') setNav(false); });

  /* Animasi muncul saat digulir */
  const reveals = $$('.reveal');
  if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    reveals.forEach((el) => io.observe(el));
  } else {
    reveals.forEach((el) => el.classList.add('in'));
  }

  /* Tab kategori menu (dipanggil ulang oleh editor setelah menu berubah) */
  window.initMenu = () => {
    const wrap = $('#menu-wrap');
    if (!wrap) return;
    const tabs = $$('.tab', wrap);
    const cards = $$('.dish', wrap);
    tabs.forEach((tab) => tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.toggle('is-active', t === tab));
      const cat = tab.dataset.cat;
      cards.forEach((c) => { c.hidden = !(cat === '*' || c.dataset.cat === cat); });
    }));
  };
  window.initMenu();

  /* Form kontak */
  const form = $('#contact-form');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = $('.form-status', form);
      const btn = $('button[type="submit"]', form);
      const say = (msg, cls) => { status.className = 'form-status ' + (cls || ''); status.textContent = msg; };

      const name = form.elements.namedItem('name').value.trim();
      const contact = form.elements.namedItem('contact').value.trim();
      const message = form.elements.namedItem('message').value.trim();
      if (!name || !contact || !message) { say('Nama, kontak, dan pesan wajib diisi.', 'err'); return; }

      btn.disabled = true;
      say('Mengirim…');
      try {
        const res = await fetch('api/contact.php', {
          method: 'POST',
          headers: { 'X-CSRF-Token': $('meta[name="csrf"]').content },
          body: new FormData(form),
          credentials: 'same-origin',
        });
        const data = await res.json();
        if (data.ok) { form.reset(); say(data.message, 'ok'); }
        else { say(data.error || 'Pesan gagal dikirim.', 'err'); }
      } catch (err) {
        say('Koneksi bermasalah. Silakan coba lagi.', 'err');
      } finally {
        btn.disabled = false;
      }
    });
  }
})();
