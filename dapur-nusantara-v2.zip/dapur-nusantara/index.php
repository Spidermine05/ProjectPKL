<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/render.php';

$admin   = is_admin();
$csrf    = csrf_token();
$heroImg = img('img.hero');
$unread  = $admin ? (int)db()->query('SELECT COUNT(*) FROM messages WHERE is_read = 0')->fetchColumn() : 0;
$wa      = wa_number(t('contact.whatsapp'));
$ig      = ltrim(trim(t('contact.instagram')), '@');
$mapUrl  = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(t('contact.address'));

/** Foto (atau ilustrasi bawaan) untuk gambar yang bisa diganti. */
function photo(string $key, string $fallback = 'assets/img/placeholder.svg'): string
{
    return e(img($key) ?? $fallback);
}
?><!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= et('brand.name') ?> — <?= et('brand.tagline') ?></title>
    <meta name="description" content="<?= et('hero.subtitle') ?>">
    <meta name="theme-color" content="#201712">
    <meta name="csrf" content="<?= e($csrf) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <script>window.DN_THEME = <?= json_encode(t('theme.data'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
    <script src="assets/js/theme.js"></script>
    <script>document.documentElement.classList.add('js');</script>
</head>
<body class="<?= $admin ? 'is-admin' : '' ?>">

<!-- ============ HEADER ============ -->
<header class="site-header">
    <div class="container header-in">
        <a href="#beranda" class="brand">
            <span class="brand-mark"><?= icon('flame', 22) ?></span>
            <span <?= ed('brand.name') ?>><?= et('brand.name') ?></span>
        </a>
        <button class="nav-toggle" type="button" aria-label="Buka menu" aria-expanded="false" aria-controls="nav">
            <span></span><span></span><span></span>
        </button>
        <nav id="nav" class="nav" aria-label="Navigasi utama">
            <a href="#beranda">Beranda</a>
            <a href="#tentang">Tentang</a>
            <a href="#menu">Menu</a>
            <a href="#galeri">Galeri</a>
            <a href="#kontak">Kontak</a>
            <a href="#kontak" class="btn btn-gold btn-sm nav-cta">Reservasi</a>
        </nav>
    </div>
</header>

<main>
<!-- ============ HERO ============ -->
<section id="beranda" class="hero<?= $heroImg ? ' has-img' : '' ?>" data-bg="img.hero"
    <?= $heroImg ? 'style="background-image:linear-gradient(rgba(20,13,9,.55),rgba(20,13,9,.8)),url(\'' . e($heroImg) . '\')"' : '' ?>>
    <div class="container hero-in">
        <p class="eyebrow eyebrow-light" <?= ed('hero.eyebrow') ?>><?= et('hero.eyebrow') ?></p>
        <h1 <?= ed('hero.title') ?>><?= et('hero.title') ?></h1>
        <p class="hero-sub pl" <?= ed('hero.subtitle', true) ?>><?= et('hero.subtitle') ?></p>
        <div class="hero-actions">
            <a href="#menu" class="btn btn-gold btn-lg" <?= ed('hero.btn1') ?>><?= et('hero.btn1') ?></a>
            <a href="#kontak" class="btn btn-outline btn-lg" <?= ed('hero.btn2') ?>><?= et('hero.btn2') ?></a>
        </div>
    </div>
    <?= media_btn('img.hero', 'Ganti foto latar') ?>
    <a href="#tentang" class="scroll-hint" aria-label="Gulir ke bawah"><span></span></a>
</section>

<!-- ============ STATISTIK ============ -->
<section class="stats" aria-label="Sekilas tentang kami">
    <div class="container stats-grid">
        <?php foreach ([1, 2, 3, 4] as $i): ?>
            <div class="stat">
                <strong <?= ed("stat$i.num") ?>><?= et("stat$i.num") ?></strong>
                <span <?= ed("stat$i.label") ?>><?= et("stat$i.label") ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- ============ TENTANG ============ -->
<section id="tentang" class="section">
    <div class="container about-grid">
        <div class="about-media reveal">
            <div class="frame ed-media">
                <img src="<?= photo('img.about') ?>" alt="Suasana dapur dan hidangan kami" data-image="img.about" loading="lazy">
                <?= media_btn('img.about') ?>
            </div>
        </div>
        <div class="about-text reveal">
            <p class="eyebrow" <?= ed('about.eyebrow') ?>><?= et('about.eyebrow') ?></p>
            <h2 <?= ed('about.title') ?>><?= et('about.title') ?></h2>
            <p class="pl" <?= ed('about.p1', true) ?>><?= et('about.p1') ?></p>
            <p class="pl" <?= ed('about.p2', true) ?>><?= et('about.p2') ?></p>
            <ul class="checks">
                <?php foreach ([1, 2, 3] as $i): ?>
                    <li><?= icon('check', 18) ?><span <?= ed("about.point$i") ?>><?= et("about.point$i") ?></span></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</section>

<!-- ============ KEUNGGULAN ============ -->
<section class="section section-sand">
    <div class="container">
        <header class="section-head reveal">
            <p class="eyebrow" <?= ed('why.eyebrow') ?>><?= et('why.eyebrow') ?></p>
            <h2 <?= ed('why.title') ?>><?= et('why.title') ?></h2>
        </header>
        <div class="why-grid">
            <?php foreach ([1 => 'leaf', 2 => 'flame', 3 => 'heart'] as $i => $ic): ?>
                <article class="why-card reveal">
                    <span class="why-ic"><?= icon($ic, 26) ?></span>
                    <h3 <?= ed("why$i.title") ?>><?= et("why$i.title") ?></h3>
                    <p class="pl" <?= ed("why$i.text", true) ?>><?= et("why$i.text") ?></p>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ============ MENU ============ -->
<section id="menu" class="section">
    <div class="container">
        <header class="section-head reveal">
            <p class="eyebrow" <?= ed('menu.eyebrow') ?>><?= et('menu.eyebrow') ?></p>
            <h2 <?= ed('menu.title') ?>><?= et('menu.title') ?></h2>
            <p class="section-sub pl" <?= ed('menu.subtitle', true) ?>><?= et('menu.subtitle') ?></p>
        </header>
        <div id="menu-wrap" class="menu-wrap"><?= render_menu($admin) ?></div>
    </div>
</section>

<!-- ============ GALERI ============ -->
<section id="galeri" class="section section-sand">
    <div class="container">
        <header class="section-head reveal">
            <p class="eyebrow" <?= ed('gallery.eyebrow') ?>><?= et('gallery.eyebrow') ?></p>
            <h2 <?= ed('gallery.title') ?>><?= et('gallery.title') ?></h2>
        </header>
        <div class="gallery reveal">
            <?php foreach ([1, 2, 3] as $i): ?>
                <figure class="gal gal-<?= $i ?> ed-media">
                    <img src="<?= photo("img.gal$i") ?>" alt="Galeri <?= $i ?>" data-image="img.gal<?= $i ?>" loading="lazy">
                    <?= media_btn("img.gal$i") ?>
                </figure>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ============ TESTIMONI ============ -->
<section class="section">
    <div class="container">
        <header class="section-head reveal">
            <p class="eyebrow" <?= ed('testi.eyebrow') ?>><?= et('testi.eyebrow') ?></p>
            <h2 <?= ed('testi.title') ?>><?= et('testi.title') ?></h2>
        </header>
        <div class="testi-grid">
            <?php foreach ([1, 2, 3] as $i): ?>
                <figure class="testi reveal">
                    <blockquote class="pl" <?= ed("t$i.text", true) ?>><?= et("t$i.text") ?></blockquote>
                    <figcaption>
                        <strong <?= ed("t$i.name") ?>><?= et("t$i.name") ?></strong>
                        <span <?= ed("t$i.role") ?>><?= et("t$i.role") ?></span>
                    </figcaption>
                </figure>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ============ AJAKAN ============ -->
<section class="cta">
    <div class="container cta-in reveal">
        <h2 <?= ed('cta.title') ?>><?= et('cta.title') ?></h2>
        <p class="pl" <?= ed('cta.text', true) ?>><?= et('cta.text') ?></p>
        <a href="#kontak" class="btn btn-light btn-lg" <?= ed('cta.btn') ?>><?= et('cta.btn') ?></a>
    </div>
</section>

<!-- ============ KONTAK ============ -->
<section id="kontak" class="section">
    <div class="container contact-grid">
        <div class="contact-info reveal">
            <p class="eyebrow" <?= ed('contact.eyebrow') ?>><?= et('contact.eyebrow') ?></p>
            <h2 <?= ed('contact.title') ?>><?= et('contact.title') ?></h2>
            <p class="pl" <?= ed('contact.text', true) ?>><?= et('contact.text') ?></p>

            <ul class="info-list">
                <li>
                    <span class="info-ic"><?= icon('pin') ?></span>
                    <div>
                        <span <?= ed('contact.address', true) ?> class="pl"><?= et('contact.address') ?></span>
                        <a class="info-link" href="<?= e($mapUrl) ?>" target="_blank" rel="noopener">Lihat di Google Maps →</a>
                    </div>
                </li>
                <li>
                    <span class="info-ic"><?= icon('phone') ?></span>
                    <div><a class="info-a" href="tel:<?= e(preg_replace('/[^0-9+]/', '', t('contact.phone'))) ?>" <?= ed('contact.phone') ?>><?= et('contact.phone') ?></a></div>
                </li>
                <li>
                    <span class="info-ic"><?= icon('mail') ?></span>
                    <div><a class="info-a" href="mailto:<?= e(t('contact.email')) ?>" <?= ed('contact.email') ?>><?= et('contact.email') ?></a></div>
                </li>
                <li>
                    <span class="info-ic"><?= icon('clock') ?></span>
                    <div>
                        <span <?= ed('contact.hours1') ?>><?= et('contact.hours1') ?></span><br>
                        <span <?= ed('contact.hours2') ?>><?= et('contact.hours2') ?></span>
                    </div>
                </li>
            </ul>
            <?php if ($admin): ?>
                <p class="hint">Nomor WhatsApp (untuk tombol chat):
                    <strong <?= ed('contact.whatsapp') ?>><?= et('contact.whatsapp') ?></strong>
                    · Instagram: @<strong <?= ed('contact.instagram') ?>><?= et('contact.instagram') ?></strong>
                </p>
            <?php endif; ?>
        </div>

        <div class="contact-form-wrap reveal">
            <form id="contact-form" class="form card-form" novalidate>
                <h3>Kirim Pesan</h3>
                <label>Nama
                    <input type="text" name="name" maxlength="80" required autocomplete="name" placeholder="Nama lengkap Anda">
                </label>
                <label>No. WhatsApp atau Email
                    <input type="text" name="contact" maxlength="120" required autocomplete="off" placeholder="0812xxxx atau nama@email.com">
                </label>
                <label>Pesan
                    <textarea name="message" rows="5" maxlength="1500" required placeholder="Contoh: Reservasi 6 orang Sabtu pukul 19.00"></textarea>
                </label>
                <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
                <button type="submit" class="btn btn-gold btn-block">Kirim Pesan</button>
                <p class="form-status" role="status" aria-live="polite"></p>
            </form>
        </div>
    </div>
</section>
</main>

<!-- ============ FOOTER ============ -->
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <a href="#beranda" class="brand brand-footer"><span class="brand-mark"><?= icon('flame', 22) ?></span><span><?= et('brand.name') ?></span></a>
            <p class="pl" <?= ed('footer.text', true) ?>><?= et('footer.text') ?></p>
        </div>
        <nav class="footer-nav" aria-label="Tautan footer">
            <a href="#tentang">Tentang</a>
            <a href="#menu">Menu</a>
            <a href="#galeri">Galeri</a>
            <a href="#kontak">Kontak</a>
        </nav>
        <div class="footer-social">
            <?php if ($ig !== ''): ?>
                <a href="https://instagram.com/<?= e(rawurlencode($ig)) ?>" target="_blank" rel="noopener" aria-label="Instagram">
                    <?= icon('instagram', 20) ?> @<?= e($ig) ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="container footer-bottom">
        <span>&copy; <?= date('Y') ?> <?= et('brand.name') ?>. Seluruh hak cipta dilindungi.</span>
        <?php if (!$admin): ?><a href="login.php" class="admin-link">Masuk admin</a><?php endif; ?>
    </div>
</footer>

<?php if ($wa !== ''): ?>
    <a class="wa-float" href="https://wa.me/<?= e($wa) ?>?text=<?= rawurlencode('Halo ' . t('brand.name') . ', saya ingin bertanya.') ?>"
       target="_blank" rel="noopener" aria-label="Chat WhatsApp"><?= icon('chat', 26) ?></a>
<?php endif; ?>

<?php if ($admin): ?>
    <!-- ============ TOOLBAR ADMIN ============
         Di layar kecil hanya ikon yang tampil (label tetap terbaca oleh pembaca layar). -->
    <div id="ed-bar" class="ed-bar" role="toolbar" aria-label="Alat edit website">
        <button type="button" id="ed-toggle" class="ed-btn ed-toggle" aria-pressed="true" title="Nyalakan / matikan Mode Edit">
            <?= icon('pencil', 18) ?><span class="ed-label">Mode Edit: Aktif</span>
        </button>
        <button type="button" id="ed-theme-btn" class="ed-btn" aria-haspopup="dialog" aria-expanded="false" aria-controls="ed-theme-panel" title="Tema website">
            <?= icon('palette', 18) ?><span class="ed-label">Tema</span>
        </button>
        <span class="ed-sep" aria-hidden="true"></span>
        <button type="button" id="ed-save" class="ed-btn ed-primary" disabled title="Simpan perubahan (Ctrl+S)">
            <?= icon('save', 18) ?><span class="ed-label">Simpan</span>
        </button>
        <button type="button" id="ed-discard" class="ed-btn" disabled title="Batalkan perubahan">
            <?= icon('undo', 18) ?><span class="ed-label">Batalkan</span>
        </button>
        <span class="ed-sep" aria-hidden="true"></span>
        <a href="admin.php" class="ed-btn" title="Pesan masuk">
            <?= icon('inbox', 18) ?><span class="ed-label">Pesan</span>
            <?php if ($unread): ?><span class="ed-badge"><?= $unread ?></span><?php endif; ?>
        </a>
        <form method="post" action="logout.php" id="ed-logout" class="ed-form">
            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
            <button type="submit" class="ed-btn" title="Keluar dari admin"><?= icon('logout', 18) ?><span class="ed-label">Keluar</span></button>
        </form>
    </div>

    <!-- ============ PANEL TEMA ============
         Sengaja di LUAR toolbar agar tidak terpotong oleh overflow / backdrop-filter toolbar. -->
    <section id="ed-theme-panel" class="ed-panel" role="dialog" aria-label="Pengaturan tema website">
        <div class="ed-panel-head">
            <div>
                <strong>Tema website</strong>
                <small>Perubahan langsung terlihat di halaman</small>
            </div>
            <button type="button" class="ed-x" id="ed-theme-close" aria-label="Tutup panel tema"><?= icon('x', 18) ?></button>
        </div>

        <p class="ed-sec">Tema siap pakai</p>
        <div class="ed-presets" id="ed-presets" role="radiogroup" aria-label="Tema siap pakai"></div>

        <p class="ed-sec">Atur warna sendiri</p>
        <div class="ed-colors">
            <label class="ed-color"><input type="color" id="ed-theme-bg" value="#faf6ee"><span><b>Latar</b><code id="hex-bg">#faf6ee</code></span></label>
            <label class="ed-color"><input type="color" id="ed-theme-text" value="#201712"><span><b>Teks</b><code id="hex-text">#201712</code></span></label>
            <label class="ed-color"><input type="color" id="ed-theme-accent" value="#b98a3c"><span><b>Aksen / tombol</b><code id="hex-accent">#b98a3c</code></span></label>
            <label class="ed-color"><input type="color" id="ed-theme-accent2" value="#9c3f26"><span><b>Aksen kedua</b><code id="hex-accent2">#9c3f26</code></span></label>
        </div>
        <p class="ed-warn" id="ed-theme-warn" role="status" hidden>Kontras teks dan latar terlalu rendah, tulisan bisa sulit dibaca.</p>

        <div class="ed-panel-foot">
            <button type="button" class="ed-reset" id="ed-theme-reset"><?= icon('undo', 15) ?> Kembalikan tema awal</button>
            <small class="ed-note">Tema tersimpan otomatis dan berlaku untuk semua pengunjung.</small>
        </div>
    </section>

    <!-- ============ DIALOG MENU ============ -->
    <dialog id="menu-dialog" class="dialog">
        <form id="menu-form" class="form dialog-form" enctype="multipart/form-data">
            <h3 id="menu-dialog-title">Tambah Menu</h3>
            <input type="hidden" name="id" value="">
            <label>Nama menu
                <input type="text" name="name" maxlength="80" required placeholder="Contoh: Soto Betawi">
            </label>
            <div class="row-2">
                <label>Kategori
                    <input type="text" name="category" maxlength="40" required list="cat-list" placeholder="Contoh: Hidangan Utama">
                    <datalist id="cat-list">
                        <?php foreach (db()->query('SELECT DISTINCT category FROM menu ORDER BY category') as $c): ?>
                            <option value="<?= e($c['category']) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </label>
                <label>Harga (Rp)
                    <input type="number" name="price" min="0" step="500" inputmode="numeric" placeholder="35000">
                </label>
            </div>
            <label>Deskripsi singkat
                <textarea name="description" rows="3" maxlength="400" placeholder="Ceritakan rasa dan bahan utamanya"></textarea>
            </label>
            <div class="photo-field">
                <img id="menu-photo-preview" src="assets/img/ph-main.svg" alt="Pratinjau foto">
                <div>
                    <label class="file-label">Foto menu (JPG/PNG/WebP, maks. 5 MB)
                        <input type="file" name="photo" accept="image/jpeg,image/png,image/webp">
                    </label>
                    <label class="check-label" id="remove-photo-wrap" hidden>
                        <input type="checkbox" name="remove_photo" value="1"> Hapus foto saat ini
                    </label>
                </div>
            </div>
            <div class="dialog-actions">
                <button type="button" class="btn btn-ghost" id="menu-cancel">Batal</button>
                <button type="submit" class="btn btn-gold">Simpan Menu</button>
            </div>
        </form>
    </dialog>

    <script src="assets/js/editor.js" defer></script>
<?php endif; ?>

<script src="assets/js/main.js" defer></script>
</body>
</html>
