# Prompt Pembuatan Website Company Profile Kuliner (PHP Native)

Salin prompt di bawah ini ke AI coding (Claude, ChatGPT, dll.) jika ingin membuat ulang atau
mengembangkan website ini dengan versi/nama bisnis Anda sendiri. Ganti bagian [dalam kurung siku].

---

Berperanlah sebagai senior PHP Native developer. Buatkan website company profile untuk bisnis
kuliner [NAMA BISNIS, mis. "Dapur Nusantara"] berupa restoran & katering.

## Teknologi
- PHP Native 8.0+ (TANPA framework, TANPA Composer), PDO + SQLite (file database dibuat otomatis,
  tidak perlu setup MySQL), HTML5, CSS3 murni (tanpa Bootstrap), JavaScript vanilla (tanpa jQuery).
- Harus berjalan di XAMPP/Laragon/hosting biasa hanya dengan menyalin folder, dan juga lewat
  `php -S localhost:8000 router.php`.

## Fitur utama: edit langsung di website (tanpa CMS terpisah)
- Halaman utama satu halaman (one-page) dengan bagian: Hero, Statistik, Tentang, Keunggulan,
  Menu (dengan tab kategori), Galeri, Testimoni, Ajakan (CTA), Kontak + form pesan, Footer.
- Saat login sebagai admin, muncul toolbar melayang: Mode Edit (aktif/mati), Simpan, Batalkan,
  Pesan, Keluar. Pada Mode Edit:
  - Semua teks (atribut `data-edit="kunci"`) bisa diklik dan diketik langsung (contenteditable),
    tempel hanya sebagai teks biasa, Enter ditolak pada teks satu baris, Ctrl+S untuk menyimpan.
  - Foto (hero, tentang, galeri) punya tombol "Ganti foto" yang langsung mengunggah.
  - Menu makanan: tombol Tambah / Ubah / Hapus lewat dialog (nama, kategori, harga, deskripsi, foto).
  - Perubahan disimpan lewat fetch ke endpoint API (JSON), ada peringatan jika meninggalkan
    halaman dengan perubahan belum tersimpan.
- Pengunjung biasa tidak melihat apa pun terkait edit.
- Pertama kali dibuka, halaman login meminta pembuatan akun admin (tanpa password bawaan).
- Halaman admin sederhana: daftar pesan masuk dari form kontak (tandai dibaca, hapus, balas via
  WhatsApp/email) dan ganti kata sandi.

## Desain
- Elegan, hangat, cocok untuk kuliner: palet espresso gelap, krem, emas, dan terakota.
- Font judul serif (Playfair Display), font isi sans (Inter) dengan fallback sistem.
- Mobile-first dan responsif penuh (HP, tablet, desktop): menu hamburger, grid fleksibel,
  tombol WhatsApp mengambang, animasi halus saat digulir (hormati prefers-reduced-motion).
- User friendly: kontras baik, target sentuh besar, label jelas, fokus keyboard terlihat.
- Teks default dalam Bahasa Indonesia, mudah diganti lewat Mode Edit.

## Keamanan (wajib)
- PDO prepared statement, `password_hash/password_verify`, `session_regenerate_id` saat login,
  token CSRF di semua POST (header `X-CSRF-Token`), logout hanya lewat POST.
- Semua output di-escape dengan `htmlspecialchars`; hanya kunci teks yang dikenal (whitelist)
  yang boleh disimpan.
- Upload foto: validasi MIME dengan `finfo` + `getimagesize`, hanya JPG/PNG/WebP, maks 5 MB,
  nama file acak, foto lama dihapus saat diganti, folder uploads tidak boleh menjalankan PHP.
- Form kontak: honeypot, batas kirim per sesi, validasi panjang. Batas percobaan login.
- Lindungi folder `data/` dan `includes/` dengan `.htaccess`, serta `router.php` untuk server bawaan PHP.

## Struktur folder
```
index.php  login.php  logout.php  admin.php  router.php
api/       save.php  upload.php  menu.php  contact.php
includes/  bootstrap.php  defaults.php  render.php
assets/    css/style.css  js/main.js  js/editor.js  img/
data/      (database SQLite, otomatis)      uploads/  (foto)
```

## Cara kerja
- Semua teks bawaan ada di `includes/defaults.php`; hasil edit disimpan di tabel `settings`
  (key-value) dan menimpa nilai bawaan. Menu, pesan, dan user punya tabel sendiri.
- Berikan juga README berisi cara menjalankan, cara memakai Mode Edit, backup, dan deploy.

Data bisnis saya:
- Nama: [NAMA]  | Slogan: [SLOGAN]
- Alamat: [ALAMAT] | WhatsApp: [NOMOR] | Email: [EMAIL] | Instagram: [@AKUN]
- Jam buka: [JAM]
- Menu unggulan (nama, kategori, harga, deskripsi): [DAFTAR MENU]

Kerjakan bertahap dan uji setiap fitur. Setelah selesai, jelaskan cara menjalankannya.
