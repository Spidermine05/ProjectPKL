# Dapur Nusantara — Website Company Profile Kuliner (PHP Native)

Website responsif (HP, tablet, desktop) yang **bisa diedit langsung di halaman website**,
tanpa CMS terpisah. Memakai PHP Native + SQLite, jadi **tidak perlu membuat database MySQL**.

## Kebutuhan
- PHP 8.0 atau lebih baru dengan ekstensi `pdo_sqlite` dan `fileinfo` (aktif bawaan di XAMPP/Laragon)
- Folder `data/` dan `uploads/` harus bisa ditulis (writable)
- Koneksi internet hanya untuk memuat font Google (jika offline, font cadangan dipakai otomatis)

## Cara menjalankan

**Laragon / XAMPP (disarankan untuk Windows)**
1. Ekstrak folder `dapur-nusantara` ke `C:\laragon\www\` atau `C:\xampp\htdocs\`
2. Nyalakan Apache, lalu buka `http://localhost/dapur-nusantara/`

**Server bawaan PHP (cepat untuk mencoba)**
```
cd dapur-nusantara
php -S localhost:8000 router.php
```
Buka `http://localhost:8000`

## Pertama kali dipakai
1. Klik **Masuk admin** di bagian bawah halaman (atau buka `/login.php`)
2. Anda akan diminta **membuat akun admin** sendiri (username + kata sandi minimal 8 karakter)
3. Setelah masuk, Anda langsung berada di **Mode Edit**

## Cara mengedit
| Yang ingin diubah | Caranya |
|---|---|
| Teks apa pun (judul, deskripsi, alamat, jam buka, testimoni, dll.) | Klik teksnya, ketik langsung, lalu klik **Simpan** (atau Ctrl+S) |
| Foto hero / tentang / galeri | Klik tombol **Ganti foto** di atas gambar (langsung tersimpan) |
| Menu makanan | Bagian Menu: **Tambah Menu**, atau **Ubah / Hapus** pada kartu menu |
| Nomor WhatsApp & Instagram | Di bagian Kontak (tampil kotak petunjuk saat mode edit) |
| Pesan dari pengunjung | Tombol **Pesan** di toolbar bawah |
| Ganti tema / warna | Tombol **palet** di toolbar |
| Melihat tampilan seperti pengunjung | Matikan **Mode Edit** di toolbar |

Format nomor WhatsApp: `081234567890` (otomatis diubah menjadi 62...).
Foto: JPG/PNG/WebP, maksimal 5 MB. Disarankan foto landscape, lebar 1200–1600 px.

## Struktur
```
index.php        halaman utama (semua bagian website)
login.php        buat akun pertama / masuk
admin.php        pesan masuk + ganti kata sandi
api/             endpoint simpan teks, upload foto, menu, form kontak
includes/        bootstrap (database, keamanan), defaults (teks bawaan), render
assets/          css, js (main.js publik; editor.js & theme.js khusus admin), gambar ilustrasi
data/            database SQLite (otomatis dibuat)
uploads/         foto yang Anda unggah
```
Teks bawaan ada di `includes/defaults.php`. Hasil edit Anda disimpan di database dan menggantikannya.

## Tema & tampilan
Saat Mode Edit, tombol **palet** di toolbar membuka panel **Tema website**:
- **Tema siap pakai**: Nusantara (asli), Sambal, Pandan, Samudra, Mawar, dan Malam (gelap). Cukup ketuk satu kartu.
- **Atur warna sendiri**: latar, teks, aksen/tombol, dan aksen kedua. Seluruh palet turunan (kartu, bagian gelap, tombol,
  kontras teks) dihitung otomatis dari 4 warna itu, jadi tema gelap tetap terbaca. Jika kontras teks & latar terlalu rendah, muncul peringatan.
- Tema **tersimpan otomatis di database** (kunci `theme.data`) dan langsung berlaku untuk semua pengunjung. Tema bawaan = Nusantara.
  Untuk mengubah warna bawaan secara permanen di kode, ubah variabel di bagian atas `assets/css/style.css` (`:root`).

Aturan warna: tiap warna dasar hanya memengaruhi bagian miliknya. **Latar** menentukan permukaan (kartu, seksi selang-seling,
hero/statistik/footer), **Teks** hanya tulisan/garis/bayangan, **Aksen** tombol dan ikon, **Aksen kedua** harga, tautan, dan CTA.
Jika teks dan latar terlalu mirip, muncul peringatan dengan tombol *Perbaiki warna teks*.

Di layar kecil (HP / jendela sempit ≤ 760 px) toolbar edit hanya berupa ikon, otomatis turun saat halaman digulir ke bawah
dan muncul lagi saat digulir ke atas. Tombol *Ganti foto* dan *Ubah/Hapus* menu juga hanya berupa ikon. **Tekan-tahan** ikon mana pun (±0,4 detik) untuk melihat namanya (tooltip); melepas jari tidak menjalankan tombol itu.

Berkas terkait: `assets/js/theme.js` (mesin tema), `assets/js/editor.js` (panel & toolbar), `assets/css/style.css` (token warna di `:root`).

## Backup
Cukup salin dua folder: **`data/`** (isi website, menu, pesan, akun) dan **`uploads/`** (foto).

## Memasang di hosting
1. Unggah seluruh isi folder ke `public_html` (cPanel/hosting PHP)
2. Pastikan `data/` dan `uploads/` writable (izin 755; jika gagal coba 775)
3. Buka `https://domainanda.com/login.php` dan buat akun admin
4. Gunakan HTTPS. Folder `data/` dan `includes/` sudah dilindungi `.htaccess` (Apache/LiteSpeed).
   Jika memakai Nginx, tambahkan aturan `location ~ ^/(data|includes)/ { deny all; }`

## Keamanan yang sudah ada
Prepared statement (PDO), kata sandi ter-hash, token CSRF, escape output, validasi upload gambar
(cek isi file, bukan hanya ekstensi), pembatasan percobaan login, honeypot + pembatas kirim di form kontak.

## Catatan
- Gambar bawaan berupa ilustrasi sederhana; ganti dengan foto asli bisnis Anda.
- Data bisnis di website (alamat, nomor telepon, dll.) adalah contoh — ubah lewat Mode Edit.
- Server bawaan PHP (`php -S`) hanya untuk pengembangan lokal, bukan untuk produksi.
