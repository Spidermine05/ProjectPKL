/* ==========================================================
   Mesin tema Dapur Nusantara
   Dari 4 warna dasar (latar, teks, aksen, aksen kedua) dihitung seluruh palet:
   permukaan kartu, bagian gelap, tombol, kontras teks, dst., lalu dipasang ke :root.
   Dimuat di <head> untuk semua pengunjung agar tema langsung terpasang tanpa kedipan.
   Tema disimpan di database (kunci 'theme.data') dan diatur admin lewat panel Tema.
   ========================================================== */
(() => {
  'use strict';

  const HEX = /^#[0-9a-f]{6}$/i;

  /* Tema siap pakai. Urutan = urutan tampil di panel. */
  const PRESETS = {
    original: { name: 'Nusantara', bg: '#faf6ee', text: '#201712', accent: '#b98a3c', accent2: '#9c3f26' },
    spice:    { name: 'Sambal',    bg: '#fff7ef', text: '#2a1710', accent: '#d9561f', accent2: '#a3281a' },
    forest:   { name: 'Pandan',    bg: '#f2f6ec', text: '#1d3123', accent: '#5e9143', accent2: '#2f6a45' },
    ocean:    { name: 'Samudra',   bg: '#eef6fa', text: '#10303f', accent: '#1f87ab', accent2: '#145f7e' },
    rose:     { name: 'Mawar',     bg: '#fff3f5', text: '#3f2029', accent: '#c8577b', accent2: '#962f55' },
    midnight: { name: 'Malam',     bg: '#1d1a26', text: '#f3edf8', accent: '#b79df0', accent2: '#e29a82' },
  };
  const KEYS = ['bg', 'text', 'accent', 'accent2'];

  /* ---------- Util warna ---------- */
  const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const toHex = (a) => '#' + a.map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, k) => { const A = rgb(a), B = rgb(b); return toHex(A.map((v, i) => v * (1 - k) + B[i] * k)); };
  const toHsl = (h) => {
    const [r, g, b] = rgb(h).map((v) => v / 255);
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    let s = 0, hue = 0;
    if (d) {
      s = d / (1 - Math.abs(2 * l - 1));
      hue = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
      hue *= 60; if (hue < 0) hue += 360;
    }
    return [hue, s, l];
  };
  const fromHsl = (h, s, l) => {
    const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
    const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
    return toHex([r + m, g + m, b + m].map((v) => v * 255));
  };
  const rgba = (h, a) => { const [r, g, b] = rgb(h); return `rgba(${r},${g},${b},${a})`; };
  const lum = (h) => {
    const [r, g, b] = rgb(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  };
  const contrast = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };

  /* Geser warna c menuju 'toward' sampai kontrasnya terhadap 'against' minimal min */
  const ensure = (c, against, min) => {
    const toward = lum(against) > 0.5 ? '#000000' : '#ffffff';
    let k = 0, out = c;
    while (contrast(out, against) < min && k < 1) { k += 0.04; out = mix(c, toward, k); }
    return out;
  };
  /* Gelapkan warna sampai luminansnya <= max (agar teks putih di atasnya terbaca) */
  const darken = (c, maxLum) => {
    let k = 0, out = c;
    while (lum(out) > maxLum && k < 1) { k += 0.04; out = mix(c, '#000000', k); }
    return out;
  };

  /* ---------- Palet turunan ---------- */
  function buildTokens(th) {
    const { bg, text, accent, accent2 } = th;
    const dark = lum(bg) < 0.28;

    const surface = dark ? mix(bg, '#ffffff', 0.07) : mix(bg, '#ffffff', 0.72);
    // Aturan: tiap warna dasar hanya boleh memengaruhi bagian yang memang miliknya.
    //  - latar (bg)   -> permukaan: kartu, seksi selang-seling, bagian gelap (hero/statistik/footer)
    //  - teks (text)  -> hanya warna tulisan, garis, dan bayangan
    //  - aksen        -> tombol, ikon, sorotan
    //  - aksen kedua  -> harga, tautan, CTA
    const [bgH, bgS, bgL] = toHsl(bg);
    const sand = dark ? mix(bg, '#000000', 0.2) : fromHsl(bgH, Math.min(1, bgS * 1.1), Math.max(0, bgL - 0.05));
    const muted = ensure(mix(text, bg, dark ? 0.34 : 0.4), dark ? surface : sand, 4.6);
    const deep = dark ? mix(bg, '#000000', 0.45) : fromHsl(bgH, Math.min(0.3, bgS * 0.5), 0.09);
    const cta1 = darken(dark ? accent : accent2, 0.16);  // tema gelap: CTA mengikuti aksen utama agar serasi

    return {
      '--cream': bg,
      '--surface': surface,
      '--sand': sand,
      '--ink': text,
      '--ink-2': mix(text, bg, 0.08),
      '--muted': muted,
      '--line': rgba(text, 0.14),
      '--gold': accent,
      '--gold-2': mix(accent, '#ffffff', 0.22),
      '--gold-hover': mix(accent, '#000000', 0.14),
      '--gold-text': ensure(accent, dark ? bg : sand, 3.2),
      '--gold-soft': rgba(accent, 0.14),
      '--gold-ring': rgba(accent, 0.2),
      '--gold-glow': rgba(accent, 0.85),
      '--on-gold': contrast('#ffffff', accent) >= 3 ? '#ffffff' : '#1b130e',
      '--terra': accent2,
      '--terra-text': ensure(accent2, dark ? surface : sand, 4.5),
      '--deep': deep,
      '--deep-2': mix(deep, '#ffffff', 0.06),
      '--deep-3': mix(deep, '#000000', 0.35),
      '--glow-1': rgba(mix(accent, '#ffffff', 0.22), 0.38),
      '--glow-2': rgba(accent2, 0.38),
      '--cta-1': cta1,
      '--cta-2': mix(cta1, '#000000', 0.4),
      '--header-bg': rgba(bg, 0.94),
      '--shadow': dark ? '0 18px 40px -22px rgba(0,0,0,.75)' : `0 18px 40px -22px ${rgba(text, 0.45)}`,
    };
  }

  /* ---------- Muat ---------- */
  const clean = (th) => {
    const out = {};
    for (const k of KEYS) out[k] = th && HEX.test(th[k]) ? th[k].toLowerCase() : PRESETS.original[k];
    return out;
  };
  const same = (a, b) => KEYS.every((k) => a[k].toLowerCase() === b[k].toLowerCase());
  const presetOf = (th) => Object.keys(PRESETS).find((id) => same(PRESETS[id], th)) || 'custom';

  /* Tema tersimpan dikirim server lewat window.DN_THEME (string JSON dari database). */
  function fromServer() {
    try {
      const saved = JSON.parse(window.DN_THEME || 'null');
      if (saved && KEYS.every((k) => HEX.test(saved[k]))) return clean(saved);
    } catch (e) { /* abaikan: pakai tema bawaan */ }
    return null;
  }

  /* ---------- Terapkan ---------- */
  let current = clean(fromServer());
  let animTimer;

  function apply(input, opts = {}) {
    const th = clean(input);
    const root = document.documentElement;
    if (opts.animate) {
      root.classList.add('theme-anim');
      clearTimeout(animTimer);
      animTimer = setTimeout(() => root.classList.remove('theme-anim'), 480);
    }
    const tokens = buildTokens(th);
    for (const [name, value] of Object.entries(tokens)) root.style.setProperty(name, value);
    root.style.colorScheme = lum(th.bg) < 0.28 ? 'dark' : 'light';
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', tokens['--deep']);
    current = th;
    document.dispatchEvent(new CustomEvent('dn-theme', { detail: th }));
    return th;
  }

  window.DNTheme = {
    PRESETS, KEYS, apply, presetOf, contrast, buildTokens,
    current: () => ({ ...current }),
  };

  /* Pasang tema tersimpan secepat mungkin (sebelum halaman tergambar, jadi tanpa kedipan).
     Tanpa tema tersimpan, CSS bawaan (= Nusantara) sudah benar. */
  const saved = fromServer();
  if (saved) apply(saved);
})();
